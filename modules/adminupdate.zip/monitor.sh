#!/system/bin/sh
MODDIR=${0%/*}
DATA=/data/adb/adminupdate
LOG=$DATA/net.log
mkdir -p "$DATA"
(
  LAST=1
  while true; do
    if dumpsys connectivity 2>/dev/null | grep -m1 'Active default network' | grep -q 'none'; then
      CUR=0
    else
      CUR=1
    fi
    if [ "$CUR" = "1" ] && [ "$LAST" = "0" ]; then
      touch "$DATA/netup"
      echo "$(date '+%F %T') online" >> "$LOG"
    fi
    LAST=$CUR
    sleep 10
  done
) &
(
  LAST=""
  while true; do
    CUR=$(pm list packages -3 2>/dev/null | sort | md5sum | cut -d' ' -f1)
    if [ "$CUR" != "$LAST" ]; then
      LAST="$CUR"
      sh "$MODDIR/auto_hide.sh" >/dev/null 2>&1
    fi
    sleep 30
  done
) &
(
  while true; do
    C=/data/data/com.miui.systemupdate/files/choice
    if [ -f "$DATA/deferred" ] && [ -f "$C" ] && [ "$(cat "$C" 2>/dev/null)" = "now" ]; then
      rm -f "$C" "$DATA/deferred" "$DATA/snooze"
      echo 1 > "$DATA/autoinstall"
      P=$(cat "$DATA/github_update.pid" 2>/dev/null)
      [ -n "$P" ] && kill "$P" 2>/dev/null
      sleep 1
      nohup sh "$MODDIR/github_update.sh" --once >/dev/null 2>&1 &
    fi
    sleep 3
  done
) &
wait
