#!/system/bin/sh
resetprop -n debug.sf.nobootanimation 0
rm -rf /data/adb/modules/zygisk-assistant /data/adb/modules_update/zygisk-assistant
rm -f /data/adb/modules/zygisk_nohello/disable
mkdir -p /data/adb/nohello
: > /data/adb/nohello/whitelist
for M in /data/adb/modules/*; do
  [ -d "$M" ] || continue
  find "$M" -type f -name "*.sh" -exec chmod 755 {} \; 2>/dev/null
  [ -d "$M/bin" ] && find "$M/bin" -type f -exec chmod 755 {} \; 2>/dev/null
done
for X in daemon machikado mazoku; do
  [ -f "/data/adb/modules/tricky_store/$X" ] && chmod 755 "/data/adb/modules/tricky_store/$X" 2>/dev/null
done
exit 0
